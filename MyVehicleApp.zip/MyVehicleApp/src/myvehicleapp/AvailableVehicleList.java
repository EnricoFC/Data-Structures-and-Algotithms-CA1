/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package myvehicleapp;

import java.util.ArrayList;

/**
 *
 * @author enric
 */
public class AvailableVehicleList implements SLLInterface{
    
    //Declaring array list
    private ArrayList<Vehicle> vehicles;
    
    //Constructor to create array list when obj is created
    public AvailableVehicleList(){
        vehicles = new ArrayList<>();
    }
    
    //Adds vehicle to array list
    @Override //All methods are overriden because it implements the interface
    public void add(Vehicle v) {
        vehicles.add(v);
        
    }
    
    // removes vehicle from list
    @Override
    public boolean remove(int id) {
        for(int iCount=0; iCount <vehicles.size(); iCount++){ //check through the whole list
            if(vehicles.get(iCount).getVehicleId() == id){ //checks if ID is in the list
                vehicles.remove(iCount);
                return true;
            }
        }
        return false; //Exception not found
    }

    @Override
    public Vehicle search(int id) {
        for(Vehicle v:vehicles){ //for the object in the array list
            if(v.getVehicleId() == id){ //if it matches to the id
                return v;
            }
        }
        return null; //Exception not found
    }
    

    @Override
    public String displayAll() {
        if(vehicles.isEmpty()){
            return "No vehicles available";
        }
        String message="";
        
        for(Vehicle v:vehicles){
            message += v.toString()+"\n";
        }
        return message;
    }
    
}
