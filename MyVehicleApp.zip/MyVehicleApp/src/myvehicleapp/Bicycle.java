/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package myvehicleapp;

/**
 *
 * @author enric
 */
public class Bicycle extends Vehicle{
    //Variable
    private boolean bike;
    
    //Constructor
    public Bicycle(boolean bike, int vehicleId, String ownerName, String brandModel, double pricePerHour, boolean available){
        super(vehicleId, ownerName, brandModel, pricePerHour, available);
        this.bike=bike;
    }
    public Bicycle(){
        super();
        bike = false;
    }

    public boolean isBike() {
        return bike;
    }

    public void setBike(boolean bike) {
        this.bike = bike;
    }
    
    @Override
    public String toString(){
        return super.toString() + bike;
    }
}
