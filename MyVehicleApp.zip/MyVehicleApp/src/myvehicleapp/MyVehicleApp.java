/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package myvehicleapp;

/**
 *
 * @author enric
 */
public class MyVehicleApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //This just declares and creates GUI so it can run the GUI when clicked to Run.
        GUI gui=new GUI();
        gui.setVisible(true);
    }
    
}
