/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package myvehicleapp;

/**
 *
 * @author enric
 */
public interface SLLInterface {
    void add(Vehicle v);
    
    boolean remove(int id);
    
    Vehicle search(int id);
    
    String displayAll();
    
}
