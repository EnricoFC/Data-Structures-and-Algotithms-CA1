/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package myvehicleapp;

/**
 *
 * @author enric
 */
public class Scooter extends Vehicle{
    //Variable
    private boolean scooter;
    
    //Contructor
    public Scooter(boolean scooter, int vehicleId, String ownerName, String brandModel, double pricePerHour, boolean available){
        super(vehicleId, ownerName, brandModel, pricePerHour, available);
        this.scooter = scooter;
    }
    public Scooter(){
        super();
        scooter = false;
    }

    public boolean isScooter() {
        return scooter;
    }

    public void setScooter(boolean scooter) {
        this.scooter = scooter;
    }
    
    @Override
    public String toString(){
        return super.toString() + scooter;
    }
}
