/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package myvehicleapp;

/**
 *
 * @author enric
 */
public class Vehicle {
    //Declare variables that fits to all vehicles.
    private int vehicleId;
    private String ownerName, brandModel;
    private double pricePerHour;
    private boolean available;
    
    //Constructor
    public Vehicle(int vehicleId, String ownerName, String brandModel, double pricePerHour, boolean available){
        this.vehicleId=vehicleId;
        this.ownerName=ownerName;
        this.brandModel=brandModel;
        this.pricePerHour=pricePerHour;
        this.available=available;
    }
    
    public Vehicle(){
        vehicleId = 0;
        ownerName = new String();
        brandModel = new String();
        pricePerHour = 0.0;
        available = false;
    }

    public int getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getBrandModel() {
        return brandModel;
    }

    public void setBrandModel(String brandModel) {
        this.brandModel = brandModel;
    }

    public double getPricePerHour() {
        return pricePerHour;
    }

    public void setPricePerHour(double pricePerHour) {
        this.pricePerHour = pricePerHour;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
    
    @Override
    public String toString(){ //A built-in method that will turn the Object vehicle into a string
        return "ID: " + vehicleId + ", Owner: " + ownerName + ", Brand/Model: " + brandModel + ", Price per Hour: " + pricePerHour + ", Available: " + available;
    }
    
}
